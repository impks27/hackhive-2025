# DeepFin Email Classification App

This application classifies emails (including attachments) of the format PDF and EML files using **DeepSeek AI** model.

## Team Name - HackHive
- Pradeep Kumar Singh
- Satheesh J Hegde
- Rahul Pandey
- Srinivas K Raghavendrarao
